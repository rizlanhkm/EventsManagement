package com.example.eventsmanagement.event_categories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import com.example.eventsmanagement.R;

public class ViewAllCategoriesActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentListCategory listCategoryFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar_layout_list_catagories);

        Toolbar toolbar = (Toolbar) findViewById(R.id.listCatToolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Category List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        fragmentManager = getSupportFragmentManager();
        listCategoryFragment = new FragmentListCategory();

        fragmentManager
                .beginTransaction()
                .replace(R.id.host_categories, listCategoryFragment)
                .commit();
    }

}