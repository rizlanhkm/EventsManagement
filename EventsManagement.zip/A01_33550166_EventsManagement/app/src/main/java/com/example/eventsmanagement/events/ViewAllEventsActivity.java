package com.example.eventsmanagement.events;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import com.example.eventsmanagement.R;

public class ViewAllEventsActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentListEvent listEventsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar_layout_list_events);

        Toolbar toolbar = (Toolbar) findViewById(R.id.listEventsToolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Events List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        fragmentManager = getSupportFragmentManager();
        listEventsFragment = new FragmentListEvent();

        fragmentManager.beginTransaction().replace(
                R.id.host_event, listEventsFragment).commit();
    }
}