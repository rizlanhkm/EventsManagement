package com.example.eventsmanagement.events;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.eventsmanagement.R;
import com.example.eventsmanagement.SMSReceiver;

import java.util.Random;
import java.util.StringTokenizer;

public class NewEventActivity extends AppCompatActivity {

    EditText etEventId, etEventName, etCategoryId, etTicketsAvailable;
    Switch swIsActive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        etEventId = findViewById(R.id.editTextEventID);
        etEventName = findViewById(R.id.editTextEventName);
        etCategoryId = findViewById(R.id.editTextEventCategoryID);
        etTicketsAvailable = findViewById(R.id.editTextTicketsAvailable);
        swIsActive = findViewById(R.id.switchEventIsActive);

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiver mbcr = new MyBroadCastReceiver();

        registerReceiver(mbcr, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
    }

    public void onSaveNewEventClick(View view){
        String eventName = etEventName.getText().toString();
        String categoryId = etCategoryId.getText().toString();
        String ticketsAvailable = etTicketsAvailable.getText().toString();
        boolean isActive = swIsActive.isChecked();

        int ticketsAvailableInt = Integer.parseInt(ticketsAvailable);

        etEventId.setText(randomEventIdGenerator());
        String eventId = etEventId.getText().toString();

        saveEventToSharedPreference(eventId, eventName, ticketsAvailableInt, categoryId, isActive);

        String success = String.format("Event %s successfully saved to %s", eventId, categoryId);
        Toast.makeText(NewEventActivity.this, success, Toast.LENGTH_SHORT).show();
    }

    private void saveEventToSharedPreference(
            String eventId,
            String eventName,
            int ticketsAvailable,
            String categoryId,
            boolean isActive){

        // initialise shared preference class variable to access Android's persistent storage
        SharedPreferences sharedPreferences = getSharedPreferences("EVENT_FILE", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString("KEY_EVENT_ID", eventId);
        editor.putString("KEY_EVENT_NAME", eventName);
        editor.putInt("KEY_TICKETS_AVAILABLE", ticketsAvailable);
        editor.putString("KEY_CATEGORY_ID", categoryId);
        editor.putBoolean("KEY_IS_ACTIVE", isActive);

        // use editor.apply() to save data to the file asynchronously (in background without freezing the UI)
        // doing in background is very common practice for any File Input/Output operations
        editor.apply();
    }

    class MyBroadCastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg){

            // check if the message starts with "event:"
            String prefix = "event:";
            if (!(msg.startsWith(prefix))){
                Toast.makeText(NewEventActivity.this, "Invalid prefix!", Toast.LENGTH_SHORT).show();
                return;
            }

            // ignore the prefix 'event:' for tokenization
            String temp = msg.substring(6);
            StringTokenizer sT = new StringTokenizer(temp, ";");


            try {
                String eventName = sT.nextToken();
                String categoryId = sT.nextToken();
                String ticketsAvailable = sT.nextToken();
                String isActive = sT.nextToken();

                int ticketsAvailableInt = Integer.parseInt(ticketsAvailable);

                // invalidate negative numbers for event count
                if (ticketsAvailableInt < 0){
                    String noNegative = "Negative value for Event Count is invalid!";
                    Toast.makeText(NewEventActivity.this, noNegative, Toast.LENGTH_SHORT).show();
                    return;
                }

                etEventName.setText(eventName);
                etCategoryId.setText(categoryId);
                etTicketsAvailable.setText(ticketsAvailable);
                swIsActive.setChecked(isActive.equals("TRUE"));

            } catch (Exception e) {
                String errorMsg = "Invalid details!";
                Toast.makeText(NewEventActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
            }

        }

    }

    private String randomEventIdGenerator(){
        int leftLimit = 65; // letter 'A'
        int rightLimit = 90; // letter 'Z'
        int targetStringLength = 3;
        String idString = "E";

        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);

        for (int i = 1; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        idString += generatedString + "-" + random5DigitGenerator();
        return idString;
    }

    private String random5DigitGenerator(){
        int leftLimit = 48; // numeral '0'
        int rightLimit = 57; // numeral '9'
        int targetStringLength = 5;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }
    // https://www.baeldung.com/java-random-string
}