package com.example.eventsmanagement;

import java.util.regex.Pattern;

public class Util {
    public static boolean specialCharacterFound(String text){
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");

        return pattern.matcher(text).find();
    }
}
