package com.example.eventsmanagement.events;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.eventsmanagement.R;
import com.example.eventsmanagement.provider.EMAViewModel;
import com.example.eventsmanagement.recycler_adapter.EventRecyclerAdapter;
import com.google.gson.Gson;

import java.util.ArrayList;

public class FragmentListEvent extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    ArrayList<Event> listEvents = new ArrayList<>();
    EventRecyclerAdapter recyclerAdapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    Gson gson = new Gson();

    private EMAViewModel emaViewModel;

    public FragmentListEvent() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_list_event, container, false);

        // get reference to recycler view
        recyclerView = view.findViewById(R.id.recyclerViewEvent);

        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        recyclerAdapter = new EventRecyclerAdapter();
        recyclerView.setAdapter(recyclerAdapter);


        emaViewModel = new ViewModelProvider(this).get(EMAViewModel.class);
        emaViewModel.getAllEvents().observe(getViewLifecycleOwner(), newData -> {
            recyclerAdapter.setData(new ArrayList<Event>(newData));
            recyclerAdapter.notifyDataSetChanged();
        });

        // Inflate the layout for this fragment
        return view;
    }
}