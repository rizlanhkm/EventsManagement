package com.example.eventsmanagement.recycler_adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventsmanagement.EMAMapsActivity;
import com.example.eventsmanagement.KeyStore;
import com.example.eventsmanagement.R;
import com.example.eventsmanagement.event_categories.EventCategory;

import java.util.List;

public class CategoryRecyclerAdapter extends RecyclerView.Adapter<CategoryRecyclerAdapter.CategoryViewHolder> {

    List<EventCategory> categories;

    /**
     *
     * @param parent The ViewGroup into which the new View will be added after it is bound to
     *               an adapter position.
     * @param viewType The view type of the new View.
     *
     * @return
     */
    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.card_layout_category, parent, false);
        CategoryViewHolder ViewHolder = new CategoryViewHolder(v);

        return ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        holder.tvCategoryId.setText((categories.get(position).getCategoryId()));
        holder.tvCategoryName.setText((categories.get(position).getCategoryName()));
        holder.tvEventCount.setText(String.valueOf(categories.get(position).getEventCount()));

        // get event location as provided by the user
        String eventLocationString = categories.get(position).getEventLocation();

        if(categories.get(position).isActive()){
            holder.tvIsActive.setText("True");
        }else{
            holder.tvIsActive.setText("False");
        }

        holder.itemView.setOnClickListener(v -> {

            // launch new Activity with supplied event location
            Context context = holder.itemView.getContext();
            Intent intent = new Intent(context, EMAMapsActivity.class);
            intent.putExtra(KeyStore.EVENT_LOCATION, eventLocationString);
            intent.putExtra(KeyStore.CATEGORY_NAME, categories.get(position).getCategoryName());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        if (this.categories != null) { // if data is not null
            return this.categories.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder{
        public TextView tvCategoryId;
        public TextView tvCategoryName;
        public TextView tvEventCount;
        public TextView tvIsActive;
        public View itemView;

        public CategoryViewHolder(@NonNull View itemView){
            super(itemView);
            this.itemView = itemView;
            tvCategoryId = itemView.findViewById(R.id.tv_category_id);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvEventCount = itemView.findViewById(R.id.tv_event_count);
            tvIsActive = itemView.findViewById(R.id.tv_active);

        }
    }

    public void setData(List<EventCategory> data) {
        this.categories = data;
    }
}
