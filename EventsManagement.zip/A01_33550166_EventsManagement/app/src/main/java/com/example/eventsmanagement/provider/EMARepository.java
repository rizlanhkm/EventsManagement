package com.example.eventsmanagement.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.eventsmanagement.event_categories.EventCategory;
import com.example.eventsmanagement.events.Event;

import java.util.List;

public class EMARepository {

    private EMADAO EMADAO;
//    private LiveData<List<Entity>> allLiveData;
    private LiveData<List<EventCategory>> allCategoriesLiveData;
    private LiveData<List<Event>> allEventsLiveData;

    // constructor to initialise the repository class
    EMARepository(Application app){
        // get reference/instance of the database
        EMADatabase db = EMADatabase.getDatabase(app);

        // get reference to DAO, to perform CRUD operations
        EMADAO = db.eventsDAO();

        // once the class is initialised get all the items in the form of LiveData
//        allLiveData = eventsDAO.getAll();
        allCategoriesLiveData = EMADAO.getAllCategories();
        allEventsLiveData = EMADAO.getAllEvents();
    }

    /**
     * Repository method to get everything
     * @return LiveData of type List<Entity>
     */
//    LiveData<List<Entity>> getAll() {
//        return allLiveData;
//    }

    /**
     * Repository method to get everything
     * @return LiveData of type List<Category>
     */
    LiveData<List<EventCategory>> getAllCategories() {
        return allCategoriesLiveData;
    }

    LiveData<List<String>> getAllCategoryIds(){
        return EMADAO.getAllCategoryIds();
    }

    LiveData<List<EventCategory>> getCategoryById(String id){
        return EMADAO.getCategoryById(id);
    }

    /**
     * Repository method to get everything
     * @return LiveData of type List<Event>
     */
    LiveData<List<Event>> getAllEvents() {
        return allEventsLiveData;
    }

    /**
     * Repository method to insert one single category
     * @param category object containing details of new Item to be inserted
     */
    void insertCategory(EventCategory category) {
        // Executes the database operation to insert the item in a background thread.
        EMADatabase.databaseWriteExecutor.execute(() -> EMADAO.addCategory(category));
    }


    /**
     * Repository method to insert one single event
     * @param event object containing details of new Item to be inserted
     */
    void insertEvent(Event event) {
        // Executes the database operation to insert the item in a background thread.
        EMADatabase.databaseWriteExecutor.execute(() -> EMADAO.addEvent(event));
    }


    /**
     * Repository method to delete all events
     */
    void deleteAllCategories() {
        // Executes the database operation to insert the item in a background thread.
        EMADatabase.databaseWriteExecutor.execute(() -> EMADAO.deleteAllCategories());
    }


    /**
     * Repository method to delete all events
     */
    void deleteAllEvents() {
        // Executes the database operation to insert the item in a background thread.
        EMADatabase.databaseWriteExecutor.execute(() -> EMADAO.deleteAllEvents());
    }

    void deleteEventByName(String name){
        EMADatabase.databaseWriteExecutor.execute(() -> EMADAO.deleteEventByName(name));
    }

    void incrementCategoryEventCountById(String CategoryId){
        EMADatabase.databaseWriteExecutor.execute(
                () -> EMADAO.incrementCategoryEventCountById(CategoryId));
    }

}
