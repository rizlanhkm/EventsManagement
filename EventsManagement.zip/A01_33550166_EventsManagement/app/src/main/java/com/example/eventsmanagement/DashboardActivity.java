package com.example.eventsmanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GestureDetectorCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;


import com.example.eventsmanagement.event_categories.EventCategory;
import com.example.eventsmanagement.event_categories.FragmentListCategory;
import com.example.eventsmanagement.event_categories.NewEventCategoryActivity;
import com.example.eventsmanagement.event_categories.ViewAllCategoriesActivity;
import com.example.eventsmanagement.events.Event;
import com.example.eventsmanagement.events.ViewAllEventsActivity;
import com.example.eventsmanagement.provider.EMAViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

public class DashboardActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle drawerToggle;

    FloatingActionButton fab;

    FragmentManager fragmentManager;
    FragmentListCategory listCategoryFragment;

    // EditText variables for event form
    EditText etEventId, etEventName, etCategoryId, etTicketsAvailable;
    Switch swIsActive;

    LiveData<List<Event>> eventsLiveData;
    LiveData<List<EventCategory>> categoriesLiveData;

    Gson gson = new Gson();

    private EMAViewModel emaViewModel;

    boolean categoryExists;

    private GestureDetectorCompat mDetector;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.drawer_layout);

        drawerLayout = findViewById(R.id.drawer_layout);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView = findViewById(R.id.nav_view);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        navigationView.setNavigationItemSelectedListener(new MyNavigationListener());

        fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSaveNewEventClick(v);
            }
        });

        fragmentManager = getSupportFragmentManager();
        listCategoryFragment = new FragmentListCategory();

        fragmentManager.beginTransaction().replace(
                R.id.host_categories_dashboard, listCategoryFragment).commit();



        // reference event form UI elements
        etEventId = findViewById(R.id.etEventId);
        etEventName = findViewById(R.id.etEventName);
        etCategoryId = findViewById(R.id.etCategoryId);
        etTicketsAvailable = findViewById(R.id.etTicketsAvailable);
        swIsActive = findViewById(R.id.swIsEventActive);

        // initialise ViewModel
        emaViewModel = new ViewModelProvider(this).get(EMAViewModel.class);

        eventsLiveData = emaViewModel.getAllEvents();
        categoriesLiveData = emaViewModel.getAllCategories();

        View touchView = findViewById(R.id.viewTouch);
        touchView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mDetector.onTouchEvent(event);
                return true;
            }
        });

        CustomGestureDetector customGestureDetector = new CustomGestureDetector();
        mDetector = new GestureDetectorCompat(this, customGestureDetector);
        mDetector.setOnDoubleTapListener(customGestureDetector);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.option_refresh) {
//            getSupportFragmentManager()
//                    .beginTransaction()
//                    .replace(R.id.frameLayout, FragmentListCategory.newInstance("", ""))
//                    .commit();
            recreate();
            Toast.makeText(this, "Page refreshed", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.option_clear_event_form) {
            // Clear event form
            onClickClearEventForm(null);
        }
        else if (id == R.id.option_delete_all_cat) {
            // Do something
//            onClickDeleteALlCategories(null);

            emaViewModel.deleteAllCategories();
            Toast.makeText(this, "All categories deleted", Toast.LENGTH_SHORT).show();
        }
        else if (id == R.id.option_delete_all_events) {
            // Do something
//            onClickDeleteAllEvents(null);

            emaViewModel.deleteAllEvents();
            Toast.makeText(this, "All events deleted", Toast.LENGTH_SHORT).show();
        }
        // tell the OS
        return true;
    }

    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.nav_all_cat) {
                // go to ViewAllCategory activity
                Intent intent = new Intent(DashboardActivity.this, ViewAllCategoriesActivity.class);

                startActivity(intent);

            } else if (id == R.id.nav_add_cat) {
                // go to NewEventCategory activity
                Intent intent = new Intent(DashboardActivity.this, NewEventCategoryActivity.class);

                startActivity(intent);

            } else if (id == R.id.nav_all_events) {
                // go to ViewAllEvents activity
                Intent intent = new Intent(DashboardActivity.this, ViewAllEventsActivity.class);

                startActivity(intent);

            } else if (id == R.id.nav_logout) {
                // remove this page from memory
                finish();

            }

            // close the drawer
            drawerLayout.closeDrawers();
            // tell the OS

            return true;
        }
    }

    public void onSaveNewEventClick(View view){
        try {
            String eventName = etEventName.getText().toString();
            String categoryId = etCategoryId.getText().toString();
            String ticketsAvailable = etTicketsAvailable.getText().toString();
            boolean isActive = swIsActive.isChecked();

            int ticketsAvailableInt = Integer.parseInt(ticketsAvailable);

            checkIfCategoryIdIsValid(categoryId);
            if (!categoryExists){
                String error = "Category ID is invalid or doesn't exist";
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

                return;
            }

            if (Util.specialCharacterFound(eventName)){
                String error = "Invalid event name";
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

                return;
            }

            if (ticketsAvailableInt < 0) {
                String error = "Invalid 'Tickets Available' (must be non-negative)";
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

                etTicketsAvailable.setText("0");
                return;
            }

            etEventId.setText(randomEventIdGenerator());
            String eventId = etEventId.getText().toString();

            Event nEvent = new Event(eventId, eventName, categoryId,ticketsAvailableInt, isActive);

            emaViewModel.insertEvent(nEvent);
            emaViewModel.incrementCategoryEventCountById(categoryId);

            String success = String.format("Event %s successfully saved to %s", eventId, categoryId);

            // snackbar doesn't work for now
//            Snackbar.make(view, success, Snackbar.LENGTH_LONG)
////                    .setAction("UNDO", new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            // undo save
////                            onClickDeleteLastSavedEvent(v, nEvent);
////                        }
////                    }).show();
            Toast.makeText(this, success, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            String errorMsg = "Invalid details!";
            Toast.makeText(DashboardActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
        }
    }

    private void checkIfCategoryIdIsValid(String categoryId) {

        LiveData<List<EventCategory>> categoryToFindLiveData = emaViewModel.getCategoryById(categoryId);

        categoryToFindLiveData.observe(this, foundData -> {

            if (foundData == null || foundData.isEmpty()){
                categoryExists = false;
            } else {
                categoryExists = true;

                categoryToFindLiveData.removeObservers(this);
            }
        });
    }
    

    public void onClickClearEventForm(View view){
        etEventId.setText("");
        etEventName.setText("");
        etCategoryId.setText("");
        etTicketsAvailable.setText("");
        swIsActive.setChecked(false);
        Toast.makeText(this, "Event form cleared", Toast.LENGTH_SHORT).show();
    }

    // function for snackbar but snackbar doesn't work at the moment
    public void onClickDeleteLastSavedEvent(View view, Event event) {
        String eventName = event.getEventName();
        emaViewModel.deleteEventByName(eventName);

        String lastEventId = event.getEventId();
        Snackbar.make(view, "Event " + lastEventId + " deleted", Snackbar.LENGTH_SHORT).show();
    }


    class MyBroadCastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg){

            // check if the message starts with "event:"
            String prefix = "event:";
            if (!(msg.startsWith(prefix))){
                Toast.makeText(DashboardActivity.this, "Invalid prefix!", Toast.LENGTH_SHORT).show();
                return;
            }

            // ignore the prefix 'event:' for tokenization
            String temp = msg.substring(6);
            StringTokenizer sT = new StringTokenizer(temp, ";");


            try {
                String eventName = sT.nextToken();
                String categoryId = sT.nextToken();
                String ticketsAvailable = sT.nextToken();
                String isActive = sT.nextToken();

                int ticketsAvailableInt = Integer.parseInt(ticketsAvailable);

                // invalidate negative numbers for event count
                if (ticketsAvailableInt < 0){
                    String noNegative = "Negative value for Event Count is invalid!";
                    Toast.makeText(DashboardActivity.this, noNegative, Toast.LENGTH_SHORT).show();
                    return;
                }

                etEventName.setText(eventName);
                etCategoryId.setText(categoryId);
                etTicketsAvailable.setText(ticketsAvailable);
                swIsActive.setChecked(isActive.equals("TRUE"));

            } catch (Exception e) {
                String errorMsg = "Invalid details!";
                Toast.makeText(DashboardActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
            }

        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    class CustomGestureDetector extends GestureDetector.SimpleOnGestureListener{
        @Override
        public void onLongPress(@NonNull MotionEvent e) {
            onClickClearEventForm(null);
            super.onLongPress(e);
        }

        @Override
        public boolean onDoubleTap(@NonNull MotionEvent e) {
            onSaveNewEventClick(null);
            return super.onDoubleTap(e);
        }
    }

    private String randomEventIdGenerator(){
        int leftLimit = 65; // letter 'A'
        int rightLimit = 90; // letter 'Z'
        int targetStringLength = 3;
        String idString = "E";

        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);

        for (int i = 1; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        idString += generatedString + "-" + random5DigitGenerator();
        return idString;
    }

    private String random5DigitGenerator(){
        int leftLimit = 48; // numeral '0'
        int rightLimit = 57; // numeral '9'
        int targetStringLength = 5;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }
    // https://www.baeldung.com/java-random-string
}