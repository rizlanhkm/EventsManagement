package com.example.eventsmanagement.login_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.eventsmanagement.KeyStore;
import com.example.eventsmanagement.R;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar_layout_register);
    }

    public void onRegisterClick (View view){

        EditText etUsername, etPassword, etConfirmPass;

        // get reference to UI elements
        etUsername = findViewById(R.id.editTextUsername);
        etPassword = findViewById(R.id.editTextPassword);
        etConfirmPass = findViewById(R.id.editTextConfirmPass);

        // using the referenced UI elements we extract values into plain text format
        String usernameString = etUsername.getText().toString();
        String passwordString = etPassword.getText().toString();
        String confirmPassString = etConfirmPass.getText().toString();

        // save data if confirm password matches with password
        if(passwordString.equals(confirmPassString) && !passwordString.equals("")) {
            Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
            saveDataToSharedPreference(usernameString, passwordString);

            goToLoginActivity();
        }
        else {
            String failMsg = "Registration failed. Please ensure all details are correct";
            Toast.makeText(this, failMsg, Toast.LENGTH_SHORT).show();
        }
    }

    private void saveDataToSharedPreference(String usernameString, String passwordString){

        // initialise shared preference class variable to access Android's persistent storage
        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.REGISTER_FILE_NAME, MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString("KEY_USERNAME", usernameString);
        editor.putString("KEY_PASSWORD", passwordString);

        // use editor.apply() to save data to the file asynchronously (in background without freezing the UI)
        // doing in background is very common practice for any File Input/Output operations
        editor.apply();

    }

    public void onAlreadyRegisteredClick(View view){
        goToLoginActivity();
    }

    private void goToLoginActivity(){
        Intent intent = new Intent(this, LoginActivity.class);

//        // initialise shared preference class variable to access Android's persistent storage
//        SharedPreferences sharedPreferences = getSharedPreferences("UNIQUE_FILE_NAME", MODE_PRIVATE);
//
//        // save key-value pairs to the shared preference file
//        String usernameRestored = sharedPreferences.getString("KEY_USERNAME", "DEFAULT_VALUE");
//        String passwordRestored = sharedPreferences.getString("KEY_PASSWORD", "DEFAULT_VALUE");
//
//        intent.putExtra("name", usernameRestored);
//        intent.putExtra("pass", passwordRestored);

        // skip to login page
        startActivity(intent);
    }
}