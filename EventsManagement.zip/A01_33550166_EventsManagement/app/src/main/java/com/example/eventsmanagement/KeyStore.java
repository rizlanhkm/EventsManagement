package com.example.eventsmanagement;

public class KeyStore {
    public static final String DEFAULT_VALUE = "DEFAULT_VALUE";

    public static final String REGISTER_FILE_NAME = "REGISTER_FILE";

    public static final String EVENT_FILE_NAME = "EVENT_FILE";

    public static final String EVENT_KEY = "EVENT_KEY";

    public static final String CATEGORY_FILE_NAME = "CATEGORY_FILE";

    public static final String CATEGORY_KEY = "CATEGORY_KEY";

    public static final String CATEGORY_ID_KEY = "CATEGORY_ID_KEY";

    public static final String CATEGORY_NAME = "CATEGORY_NAME";

    public static final String EVENT_NAME = "EVENT_NAME";

    public static final String EVENT_LOCATION = "EVENT_LOCATION";
}
