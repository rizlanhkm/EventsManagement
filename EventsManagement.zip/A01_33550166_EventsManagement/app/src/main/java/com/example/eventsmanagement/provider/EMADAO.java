package com.example.eventsmanagement.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.eventsmanagement.event_categories.EventCategory;
import com.example.eventsmanagement.events.Event;

import java.util.List;

@Dao
public interface EMADAO {

    // Specifies a database query to retrieve all items from the "categories" and "events" table.
//    @Query("select * from categories, events")
//    LiveData<List<Entity>> getAll(); // Returns a LiveData object containing a list of EventCategory and Event objects.

    @Query("select * from categories")
    LiveData<List<EventCategory>> getAllCategories();

    @Query("select categoryId from categories")
    LiveData<List<String>> getAllCategoryIds();

    @Query("SELECT * FROM categories WHERE categoryId = :id")
    LiveData<List<EventCategory>> getCategoryById(String id);

    @Query("select * from events")
    LiveData<List<Event>> getAllEvents();

    @Insert
    void addCategory(EventCategory category);

    @Insert
    void addEvent(Event event);

    @Query("DELETE FROM categories")
    void deleteAllCategories();

    @Query("DELETE FROM events")
    void deleteAllEvents();

    @Query("DELETE from events where eventName = :name")
    void deleteEventByName(String name);

    @Query("UPDATE categories SET eventCount = eventCount + 1 WHERE categoryId = :CategoryId")
    void incrementCategoryEventCountById(String CategoryId);
}
