package com.example.eventsmanagement.login_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.eventsmanagement.DashboardActivity;
import com.example.eventsmanagement.KeyStore;
import com.example.eventsmanagement.R;

public class LoginActivity extends AppCompatActivity {

    String usernameRestored, passwordRestored;
    EditText etUsername, etPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar_layout_login);

//        Toolbar toolbar = (Toolbar) findViewById(R.id.listEventsToolbar);
//        setSupportActionBar(toolbar);
//
//        getSupportActionBar().setTitle("Login");
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);

        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.REGISTER_FILE_NAME, MODE_PRIVATE);

        // save key-value pairs to the shared preference file
        usernameRestored = sharedPreferences.getString("KEY_USERNAME", "DEFAULT_VALUE");
        passwordRestored = sharedPreferences.getString("KEY_PASSWORD", "DEFAULT_VALUE");

        etUsername = findViewById(R.id.editTextUsernameLogin);
        etPassword = findViewById(R.id.editTextPasswordLogin);

        etUsername.setText(usernameRestored);
        etPassword.setText(passwordRestored);
    }

    public void onLoginClick(View view){
        String inputUsername = etUsername.getText().toString();
        String inputPassword = etPassword.getText().toString();

        if (inputUsername.equals(usernameRestored) && inputPassword.equals(passwordRestored)){
            Toast.makeText(this, String.format("Welcome, %s!", inputUsername), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, DashboardActivity.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this,
                    "Please ensure that your user login details are correct",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void onToRegisterClick(View view){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

}