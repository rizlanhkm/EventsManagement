package com.example.eventsmanagement.event_categories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.eventsmanagement.KeyStore;
import com.example.eventsmanagement.R;
import com.example.eventsmanagement.SMSReceiver;
import com.example.eventsmanagement.Util;
import com.example.eventsmanagement.provider.EMAViewModel;
import com.google.gson.Gson;

import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

public class NewEventCategoryActivity extends AppCompatActivity {

    EditText etCategoryId, etCategoryName, etEventCount, etLocation;
    Switch swIsActive;

    LiveData<List<EventCategory>> categories;
    String categoriesString;

    LiveData<List<String>> categoryIdList;
    String categoryIdListString;

    SharedPreferences sharedPreferences;

    Gson gson = new Gson();

    private EMAViewModel emaViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar_layout_new_category);

        emaViewModel = new ViewModelProvider(this).get(EMAViewModel.class);

        etCategoryId = findViewById(R.id.editTextCategoryID);
        etCategoryName = findViewById(R.id.editTextCategoryName);
        etEventCount = findViewById(R.id.editTextEventCount);
        swIsActive = findViewById(R.id.switchIsActive);
        etLocation = findViewById(R.id.editTextCategoryLocation);

        sharedPreferences = getSharedPreferences(KeyStore.CATEGORY_FILE_NAME, MODE_PRIVATE);

//        categoriesString = sharedPreferences.getString(KeyStore.CATEGORY_KEY, "[]");
//        categoryIdListString = sharedPreferences.getString(KeyStore.CATEGORY_ID_KEY, "DEFAULT_VALUE");
//        Type type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        categories = gson.fromJson(categoriesString, type);
//        Type type2 = new TypeToken<ArrayList<String>>() {}.getType();
//        categoryIdList = gson.fromJson(categoryIdListString, type2);

        categories = emaViewModel.getAllCategories();
        categoryIdList = emaViewModel.getAllCategoryIds();

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiver mbcr = new MyBroadCastReceiver();

        registerReceiver(mbcr, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);

        Toolbar toolbar = (Toolbar) findViewById(R.id.newCatToolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("New Category");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public void onSaveNewEventCategoryClick(View view) {
        try {
            String categoryName = etCategoryName.getText().toString();
            String eventCount = etEventCount.getText().toString();
            boolean isActive = swIsActive.isChecked();
            String Location = etLocation.getText().toString();

            int eventCountInt = Integer.parseInt(eventCount);

            if (Util.specialCharacterFound(categoryName)){
                String error = "Invalid category name";
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

                return;
            }

            if (eventCountInt < 0) {
                String error = "Invalid event count (must be non-negative)";
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

                etEventCount.setText("0");
                return;
            }

            etCategoryId.setText(randomCategoryIdGenerator());
            String categoryId = etCategoryId.getText().toString();


            EventCategory nEventCategory = new EventCategory(
                    categoryId, categoryName, eventCountInt, isActive, Location);

            emaViewModel.insertCategory(nEventCategory);

//
//            saveArrayListAsText();

            String success = "Category saved succesfully: " + categoryId;
            Toast.makeText(NewEventCategoryActivity.this, success, Toast.LENGTH_SHORT).show();


            finish();

        } catch (Exception e) {
            String errorMsg = "Invalid details!";
            Toast.makeText(NewEventCategoryActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
        }
    }

    class MyBroadCastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg){

            // check if the message starts with "category:"
            String prefix = "category:";
            if (!(msg.startsWith(prefix))){
                Toast.makeText(NewEventCategoryActivity.this, "Invalid prefix!", Toast.LENGTH_SHORT).show();
                return;
            }

            // ignore the prefix 'category:' for tokenization
            String temp = msg.substring(9);
            StringTokenizer sT = new StringTokenizer(temp, ";");


            try {
                String categoryName = sT.nextToken();
                String eventCount = sT.nextToken();
                String isActive = sT.nextToken();

                int eventCountInt = Integer.parseInt(eventCount);

                // invalidate negative numbers for event count
                if (eventCountInt < 0){
                    String noNegative = "Negative value for Event Count is invalid!";
                    Toast.makeText(NewEventCategoryActivity.this, noNegative, Toast.LENGTH_SHORT).show();
                    return;
                }

                // only allows "TRUE" or "FALSE" for isActive detail
                if (!(isActive.equals("TRUE")) && !(isActive.equals("FALSE"))){
                    String onlyBool = "Is Active? should only be 'TRUE' or 'FALSE'";
                    Toast.makeText(NewEventCategoryActivity.this, onlyBool, Toast.LENGTH_SHORT).show();
                    return;
                }

                etCategoryName.setText(categoryName);
                etEventCount.setText(eventCount);
                swIsActive.setChecked(isActive.equals("TRUE"));

            } catch (Exception e) {
                String errorMsg = "Invalid details!";
                Toast.makeText(NewEventCategoryActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
            }

        }

    }

//    public void saveArrayListAsText(){
//        String arrayListString =gson.toJson(categories);
//        String IdListString = gson.toJson(categoryIdList);
//
//        SharedPreferences.Editor edit = sharedPreferences.edit();
//        edit.putString(KeyStore.CATEGORY_KEY, arrayListString);
//        edit.putString(KeyStore.CATEGORY_ID_KEY, IdListString);
//        edit.apply();
//    }

    private String randomCategoryIdGenerator(){
        int leftLimit = 65; // letter 'A'
        int rightLimit = 90; // letter 'Z'
        int targetStringLength = 3;
        String idString = "C";

        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);

        for (int i = 1; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        idString += generatedString + "-" + random4DigitGenerator();
        return idString;
    }

    private String random4DigitGenerator(){
        int leftLimit = 48; // numeral '0'
        int rightLimit = 57; // numeral '9'
        int targetStringLength = 4;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }
    // https://www.baeldung.com/java-random-string
}