package com.example.eventsmanagement.recycler_adapter;



import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventsmanagement.KeyStore;
import com.example.eventsmanagement.R;
import com.example.eventsmanagement.WebResults;
import com.example.eventsmanagement.events.Event;

import java.util.ArrayList;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.EventViewHolder>  {

    ArrayList<Event> events = new ArrayList<>();

    /**
     *
     * @param parent The ViewGroup into which the new View will be added after it is bound to
     *               an adapter position.
     * @param viewType The view type of the new View.
     *
     * @return
     */
    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.card_layout_event, parent, false);
        EventViewHolder ViewHolder = new EventViewHolder(v);

        return ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        holder.tvEventId.setText((events.get(position).getEventId()));
        holder.tvEventName.setText((events.get(position).getEventName()));
        holder.tvCategoryId.setText((events.get(position).getCategoryId()));
        holder.tvTicketsAvailable.setText(String.valueOf(events.get(position).getTicketsAvailable()));

        if(events.get(position).isActive()){
            holder.tvIsActive.setText("True");
        }else{
            holder.tvIsActive.setText("False");
        }

        holder.itemView.setOnClickListener(v -> {
            // get country name as provided by the user
            String eventNameString = holder.tvEventName.getText().toString();

            // launch new Activity with supplied event name
            Context context = holder.itemView.getContext();
            Intent intent = new Intent(context, WebResults.class);
            intent.putExtra(KeyStore.EVENT_NAME, eventNameString);
            context.startActivity(intent);

        });
    }

    @Override
    public int getItemCount() {
        if (this.events != null) { // if data is not null
            return this.events.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public class EventViewHolder extends RecyclerView.ViewHolder{
        public TextView tvEventId;
        public TextView tvEventName;
        public TextView tvCategoryId;
        public TextView tvTicketsAvailable;
        public TextView tvIsActive;

        public EventViewHolder(@NonNull View itemView){
            super(itemView);
            tvEventId = itemView.findViewById(R.id.tv_event_id);
            tvEventName = itemView.findViewById(R.id.tv_event_name);
            tvCategoryId = itemView.findViewById(R.id.tv_category_id);
            tvTicketsAvailable = itemView.findViewById(R.id.tv_tickets_available);
            tvIsActive = itemView.findViewById(R.id.tv_is_active);

        }
    }

    public void setData(ArrayList<Event> data) {
        this.events = data;
    }

    public ArrayList<Event> getData(){
        return this.events;
    }
}
