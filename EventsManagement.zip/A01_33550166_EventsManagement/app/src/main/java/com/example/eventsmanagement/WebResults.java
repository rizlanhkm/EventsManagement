package com.example.eventsmanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class WebResults extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_results);

        Toolbar toolbar = (Toolbar) findViewById(R.id.web_toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Web results");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // using the ID set in previous step, get reference to the WebView
        WebView webView = findViewById(R.id.webView);

        // get country name from Intent
        String eventName = getIntent().getExtras().getString(KeyStore.EVENT_NAME);

        // compile the Wikipedia URL, which will be used to load into WebView
        String googleResults = "https://www.google.com/search?q=" + eventName;

        // set new WebView Client for the WebView
        // This gives the WebView ability to be load the URL in the current WebView
        // instead of navigating to default web browser of the device
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(googleResults);
    }
}