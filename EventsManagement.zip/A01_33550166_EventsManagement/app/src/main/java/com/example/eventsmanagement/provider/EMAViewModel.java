package com.example.eventsmanagement.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.eventsmanagement.event_categories.EventCategory;
import com.example.eventsmanagement.events.Event;

import java.util.List;

public class EMAViewModel extends AndroidViewModel {

    // reference to EventsRepository
    private EMARepository repository;

    // private class variable to temporary hold all the items retrieved and pass outside of this class
    private LiveData<List<EventCategory>> allCategoryLiveData;
    private LiveData<List<Event>> allEventsLiveData;



    public EMAViewModel(@NonNull Application application) {
        super(application);

        // get reference to the repository class
        repository = new EMARepository(application);

        // get all items by calling method defined in repository class
//        allLiveData = repository.getAll();
        allCategoryLiveData = repository.getAllCategories();
        allEventsLiveData = repository.getAllEvents();
    }


    /**
     * ViewModel method to get all cards
     * @return LiveData of type List<EventCategory>
     */
    public LiveData<List<EventCategory>> getAllCategories() {
        return allCategoryLiveData;
    }

    public LiveData<List<String>> getAllCategoryIds(){
        return repository.getAllCategoryIds();
    }

    /**
     * ViewModel method to get all cards
     * @return LiveData of type List<Event>
     */
    public LiveData<List<Event>> getAllEvents() {
        return allEventsLiveData;
    }

    public LiveData<List<EventCategory>> getCategoryById(String id){
        return repository.getCategoryById(id);
    }

    /**
     * ViewModel method to insert one single category,
     * usually calling insert method defined in repository class
     * @param category object containing details of new Item to be inserted
     */
    public void insertCategory(EventCategory category) {
        repository.insertCategory(category);
    }

    /**
     * ViewModel method to insert one single category,
     * usually calling insert method defined in repository class
     * @param event object containing details of new Item to be inserted
     */
    public void insertEvent(Event event) {
        repository.insertEvent(event);
    }

    public void deleteAllCategories(){
        repository.deleteAllCategories();
    }

    public void deleteAllEvents(){
        repository.deleteAllEvents();
    }
    public void deleteEventByName(String name){
        repository.deleteEventByName(name);
    }

    public void incrementCategoryEventCountById(String CategoryId){
        repository.incrementCategoryEventCountById(CategoryId);
    }
}
